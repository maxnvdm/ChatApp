package sample;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

import javax.swing.*;
import java.awt.*;
//import java.awt.event.KeyEvent;
import javafx.scene.input.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClientGUI extends Thread implements Initializable {

    Desktop desktop = Desktop.getDesktop();

    public ListView lstDisplay;
    public AnchorPane anchorPane;
    public Button btnAttach;
    public Button btnLogin;
    public ImageView imgSend;
    public TextField txtMessage;
    public Button btnSend;
    public ListView lstUsers;
    public ImageView imgAttach;
    private Socket socket; 				//to connect through the socket
    private OutputStream out ; 			//to give output
    private Writer outWriter;			//to write that output
    private BufferedWriter buffWriter;	//using a buffWriter
    private DataInputStream dataIn;
    private DataOutputStream dataOut;
    //
    private boolean loggedIn = false;
    protected String server_name, port, your_name;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    }

    //Connect method to connect the client to the server based on the IP and port number
    //given during setup--working
    public void connect(String server_name, String port, String your_name) throws IOException
    {
        socket = new Socket(server_name,Integer.parseInt(port)); 	//connects through socket to IP
        out = socket.getOutputStream(); 												//gets the out stream
        outWriter = new OutputStreamWriter(out); 										//makes it write-able
        buffWriter = new BufferedWriter(outWriter); 									//using a buffWriter
        buffWriter.write(your_name+"\r\n"); 								        //sends first message to server as name, server knows this on line 58
        buffWriter.flush(); 															//admin
    }

    public void listen()
    {
        ListenThread listenThread = new ListenThread(socket, lstDisplay, this);
        listenThread.start();
    }

    void displayText(String message) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                lstDisplay.getItems().add(message);
            }
        });
    }

    public void sendMessage(MouseEvent actionEvent) {
        sendMessage(txtMessage.getText());
    }

    public void sendMessage(String message) {
        try {
            if(message.equals("EXIT"))															//if user wants to exit
            {
                sendMessage(your_name+" has left");

                //buffWriter.write("Disconnected \r\n");
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        lstDisplay.getItems().add("Disconnected \r\n");
                    }
                });
            }
            else																			//else send the message
            {
                buffWriter.write(message+"\n");
                if (!message.contains("CLIENTNAME:")) {
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            lstDisplay.getItems().add("You :> " + message + "\n");
                        }
                    });
                }
            }
            buffWriter.flush(); 															//admin
            txtMessage.setText("");														    //reset text variable
        } catch (IOException e) {e.printStackTrace();}
    }

    public void displayUsername(String name) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                lstUsers.getItems().add(name);
            }
        });
    }

    //method to trigger send message if enter key is pressed
    public void keyPressed(javafx.scene.input.KeyEvent keyEvent) {
        if(keyEvent.getCode()==KeyCode.ENTER) {
            sendMessage(txtMessage.getText());
        }
    }

    public void changeSession(ActionEvent actionEvent) {
        if (!loggedIn) {
            JPanel panel = new JPanel(new BorderLayout(5, 5));

            JPanel label = new JPanel(new GridLayout(0, 1, 3, 3));
            label.add(new JLabel("Server name", SwingConstants.RIGHT));
            label.add(new JLabel("Port", SwingConstants.RIGHT));
            label.add(new JLabel("Your name", SwingConstants.RIGHT));
            panel.add(label, BorderLayout.WEST);

            JPanel controls = new JPanel(new GridLayout(0, 1, 2, 2));
            JTextField server_name_field = new JTextField("Dominic-PC"); // debug
            controls.add(server_name_field);
            JTextField port_field = new JTextField("2018"); // debug
            controls.add(port_field);
            JTextField your_name_field = new JTextField();
            controls.add(your_name_field);
            panel.add(controls, BorderLayout.CENTER);

            JOptionPane.showConfirmDialog(null , panel, "Connect to Server", JOptionPane.OK_CANCEL_OPTION);

            server_name = server_name_field.getText();
            port = port_field.getText();
            your_name = your_name_field.getText();

            if ((!server_name.equals(""))&&(!port.equals(""))&&(!your_name.equals(""))) {
                // connect to server
                try {
                    connect(server_name, port, your_name);
                    System.out.println("Connected to server");
                    listen();
                    //
                    loggedIn = true;
                    //
                    sendMessage("CLIENTNAME:" + your_name);
                    //
                    btnLogin.setText("Go Offline");
                    btnLogin.getStyleClass().clear();
                    btnLogin.getStyleClass().add("green");
                    btnLogin.setTextAlignment(TextAlignment.CENTER);
                    enableElements();
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            lstDisplay.getItems().clear();
                            lstDisplay.getItems().add("Connected");
                        }
                    });
                    //btnLogin.getStyleClass().add()
                } catch (IOException e) {e.printStackTrace();}
            } else {
                JOptionPane.showMessageDialog(null, "Failed to establish connection. Please try again.", "Connection Status",JOptionPane.OK_OPTION);
            }
        } else {
            try {
                endSession();
            } catch(IOException e) {e.printStackTrace();}
        }
    }

    public void attachFile(ActionEvent actionEvent) {
        Stage stage = new Stage();
        stage.setTitle("File Chooser");

        final FileChooser fileChooser = new FileChooser();

        final TextField fileDisplay = new TextField();
        fileDisplay.setEditable(false);
        final Button openButton = new Button("Browse for file");
        final Button confirmationButton = new Button("Send");
        confirmationButton.setDisable(true);
        File fileToSend = fileChooser.showOpenDialog(stage);

        openButton.setOnAction(
                new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(final ActionEvent e) {
                        configureFileChooser(fileChooser);
                        if (fileToSend != null) {
                            fileDisplay.setText(fileToSend.getAbsolutePath());
                            //openFile(file);
                            confirmationButton.setDisable(false);
                        }
                    }
                });

        confirmationButton.setOnAction(
                new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                sendMessage("file sent from: " + fileToSend.getName());
                stage.close();
            }
        });

        final GridPane inputGridPane = new GridPane();

        GridPane.setConstraints(openButton, 1, 0);
        GridPane.setConstraints(fileDisplay, 0, 0);
        GridPane.setConstraints(confirmationButton, 1, 1);
        inputGridPane.setHgap(6);
        inputGridPane.setVgap(6);
        inputGridPane.getChildren().addAll(openButton, fileDisplay, confirmationButton);
        GridPane.setHalignment(confirmationButton, HPos.RIGHT);

        final Pane rootGroup = new VBox(12);
        rootGroup.getChildren().addAll(inputGridPane);
        rootGroup.setPadding(new Insets(12, 12, 12, 12));

        stage.setScene(new Scene(rootGroup));
        stage.show();
    }

    private void openFile(File file) {
        try {
            desktop.open(file);
        } catch (IOException ex) {
            Logger.getLogger(
                    FileChooserSample.class.getName()).log(
                    Level.SEVERE, null, ex
            );
        }
    }

    private static void configureFileChooser(final FileChooser fileChooser){
        fileChooser.setTitle("Select File");
        fileChooser.setInitialDirectory(
                new File(System.getProperty("user.home"))
        );
    }

    public void removeUser(String user) {
        if (lstUsers.getItems().contains(user)) lstUsers.getItems().remove(user);
    }

    public void enableElements() {
        txtMessage.setEditable(true);
        btnSend.setDisable(false);
        btnAttach.setDisable(false);
        imgSend.setDisable(false);
        imgAttach.setDisable(false);
    }

    public void disableElements() {
        txtMessage.setEditable(false);
        btnSend.setDisable(true);
        btnAttach.setDisable(true);
        imgSend.setDisable(true);
        imgAttach.setDisable(true);
    }

    //this method is used when the client exits to close all connections and possible resource leaks
    public void endSession() throws IOException
    {
        sendMessage("EXIT");															//tell server that we are exiting
        buffWriter.close();																//close the bufferedWirter
        outWriter.close();																//close the outWriter that made the stream write-able
        out.close();																	//close the output stream
        socket.close();																	//close the socket
        loggedIn = false;
        btnLogin.setText("Go Online");
        btnLogin.getStyleClass().clear();
        btnLogin.getStyleClass().add("round-red");
        disableElements();
    }
}

package sample;

import javafx.scene.control.ListView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;

public class ListenThread extends Thread {

    public ListView lstDisplay;
    private Socket socket;
    private ClientGUI cg;

    public ListenThread(Socket socket, ListView lstDisplay, ClientGUI cg) {
        this.socket = socket;
        this.lstDisplay = lstDisplay;
        this.cg = cg;
    }

    @Override
    public void run() {
        System.out.println("running");
        super.run();
        try {
            String mesg = "";
            do {
                //cg.displayUsernames();
                InputStream input = socket.getInputStream();
                InputStreamReader inputRead = new InputStreamReader(input);
                BufferedReader buffRead = new BufferedReader(inputRead);

                if (buffRead.ready()) {
                    //System.out.println("buff ready");
                    mesg = buffRead.readLine();
                    if (mesg.equals("EXIT")) {
                        cg.displayText("Server out!");
                    } else if (mesg.contains("CLIENTNAME:")) {
                        String name = mesg.substring(mesg.indexOf(":")+1, mesg.length());
                        if (!cg.lstUsers.getItems().contains(name)) {
                            cg.displayUsername(name);
                            cg.sendMessage("CLIENTNAME:" + cg.your_name);
                            //System.out.println("New user. " + cg.your_name + " sent my name back.");
                        }
                    } else if (mesg.contains("REMOVECLIENT:")) {
                        cg.removeUser(mesg.substring(mesg.indexOf(":")+1, mesg.length()));
                    }else {
                        //System.out.println(mesg);
                        cg.displayText(mesg);
                    }
                }
            } while (!mesg.equals("EXIT")&&!socket.isClosed());
        } catch (IOException e) {e.printStackTrace();}
    }
}

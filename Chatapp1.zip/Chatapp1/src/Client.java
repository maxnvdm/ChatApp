
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.nio.file.Files;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

class Client extends JFrame implements ActionListener, KeyListener, MouseListener
{
    //Decelerations of variables
    private static final long serialVersionUID = 1L;
    //UI elements
    private JTextArea text;
    private JTextField textMessage;
    private JTextField imageName;
    private JButton sendImage;
    private JButton btnSend;
    private JButton btnLogout;
    private JLabel lblChat;
    private JLabel lblMessage;
    private JPanel panelContent;
    private JTextField textIP;
    private JTextField textPort;
    private JTextField textName;
    //IO things
    private Socket socket; 				//to connect through the socket
    private OutputStream out ; 			//to give output
    private Writer outWriter;			//to write that output
    private BufferedWriter buffWriter;	//using a buffWriter
    private DataInputStream dataIn;
    private DataOutputStream dataOut;

    private int bytesRead;
    private int current ;
    private FileOutputStream fos ;
    private BufferedOutputStream bos ;

    private FileInputStream fis = null;
    private BufferedInputStream bis = null;
    private OutputStream os = null;

    //constructor method will instantiate variables and create the UI
    public Client() throws IOException
    {
        //first just basic UI setup stuff
        lblMessage = new JLabel("cool!");
        textIP = new JTextField(""+InetAddress.getLocalHost());
        textPort = new JTextField("11111");
        textName = new JTextField("neo");
        Object[] inputParams = {lblMessage, textIP, textPort, textName };
        JOptionPane.showMessageDialog(null, inputParams);


        //CLIENT GUI SETUP

        getContentPane().setBackground(Color.DARK_GRAY);
        setFont(new Font("Comic Sans MS", Font.PLAIN, 12));
        setTitle("ChatApp");

        imageName = new JTextField();
        imageName.setFont(new Font("Comic Sans MS", Font.ITALIC, 11));
        imageName.setHorizontalAlignment(SwingConstants.CENTER);
        imageName.setText("Enter name of image to be sent");
        imageName.setColumns(10);

        sendImage = new JButton("Send image");
        sendImage.setForeground(Color.RED);
        sendImage.setFont(new Font("Comic Sans MS", Font.PLAIN, 12));

        textMessage = new JTextField();
        textMessage.setHorizontalAlignment(SwingConstants.CENTER);
        textMessage.setText("Enter text message");
        textMessage.setFont(new Font("Comic Sans MS", Font.ITALIC, 11));
        textMessage.setColumns(10);

        btnSend = new JButton("Send text");
        btnSend.setForeground(Color.RED);
        btnSend.setFont(new Font("Comic Sans MS", Font.PLAIN, 12));

        btnLogout = new JButton("Log out");
        btnLogout.setForeground(Color.RED);
        btnLogout.setFont(new Font("Comic Sans MS", Font.PLAIN, 12));

        text = new JTextArea();
        GroupLayout groupLayout = new GroupLayout(getContentPane());
        groupLayout.setHorizontalGroup(
                groupLayout.createParallelGroup(Alignment.LEADING)
                        .addGroup(groupLayout.createSequentialGroup()
                                .addGap(2)
                                .addComponent(textMessage, GroupLayout.PREFERRED_SIZE, 331, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addComponent(btnSend, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
                                .addContainerGap())
                        .addComponent(text, GroupLayout.DEFAULT_SIZE, 442, Short.MAX_VALUE)
                        .addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
                                .addComponent(imageName, GroupLayout.PREFERRED_SIZE, 332, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addComponent(sendImage, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
                        .addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
                                .addContainerGap(289, Short.MAX_VALUE)
                                .addComponent(btnLogout, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
        );
        groupLayout.setVerticalGroup(
                groupLayout.createParallelGroup(Alignment.TRAILING)
                        .addGroup(groupLayout.createSequentialGroup()
                                .addComponent(text, GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
                                        .addComponent(btnSend, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(textMessage, GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE))
                                .addPreferredGap(ComponentPlacement.UNRELATED)
                                .addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(sendImage, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(imageName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addComponent(btnLogout))
        );
        getContentPane().setLayout(groupLayout);
        setLocationRelativeTo(null);
        setResizable(false);
        setSize(450,500);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        //action listeners for buttons
        btnSend.addActionListener(this);
        btnLogout.addActionListener(this);
        btnSend.addKeyListener(this);
        textMessage.addKeyListener(this);
        sendImage.addActionListener(this);
        sendImage.addKeyListener(this);
        textMessage.addMouseListener(this);
        imageName.addMouseListener(this);
    }

    //Connect method to connect the client to the server based on the IP and port number
//given during setup--working
    public void connect() throws IOException
    {
        socket = new Socket(textIP.getText(),Integer.parseInt(textPort.getText())); 	//connects through socket to IP
        out = socket.getOutputStream(); 												//gets the out stream
        outWriter = new OutputStreamWriter(out); 										//makes it write-able
        buffWriter = new BufferedWriter(outWriter); 									//using a buffWriter
        buffWriter.write(textName.getText()+"\r\n"); 									//sends first message to server as name, server knows this on line 58
        buffWriter.flush(); 															//Admin
    }

    //Send message is used to send the string through to the server when the button is pressed, or if enter is pressed
    public void sendMessage(String s) throws IOException
    {
        if(s.equals("EXIT"))															//if user wants to exit
        {
            sendMessage(textName.getText()+" has left");
            buffWriter.write("Disconnected \r\n");
            text.append("Disconnected \r\n");
        }
        else																			//else send the message
        {
            buffWriter.write(s+"\n");
            text.append( textName.getText() + ": " + s+"\n");
        }
        buffWriter.flush(); 															//Admin
        textMessage.setText("");														//reset text variable
    }

    //now we have listen() the method to take incoming messages
    public void listen() throws IOException
    {
        InputStream input = socket.getInputStream();
        InputStreamReader inputRead = new InputStreamReader(input);
        BufferedReader buffRead = new BufferedReader(inputRead);
        String mesg = "";
        while(!mesg.equals("EXIT"))
        {
            if(buffRead.ready())
            {
                mesg = buffRead.readLine();
                if(mesg.equals("EXIT")) {text.append("Server out! \r\n");}
                if(mesg.indexOf("**")>-1){


                    if(imgNotification()==0){
                        imageReceive(mesg.substring(2),"dog.jpg");

                    }
                    else{
                        text.append(mesg+"'s image declined!!|-_-|\r\n");
                    }

                }
                else {
                    //System.out.println("append normal shii");
                    text.append(mesg+"\r\n");
                }
            }
        }
    }

    //this method is used when the client exits to close all connections and possible resource leaks
    public void exit() throws IOException
    {
        sendMessage("EXIT");															//tell server that we are exiting
        buffWriter.close();																//close the bufferedWirter
        outWriter.close();																//close the outWriter that made the stream write-able
        out.close();																	//close the output stream
        socket.close();																	//close the socket
    }

    //this method is required and will outline what happens when a given button is pressed
    public void actionPerformed(ActionEvent x)
    {
        try
        {
            if (x.getActionCommand().equals(btnSend.getActionCommand()))					//send message
            {
                sendMessage(textMessage.getText());
            }
            if (x.getActionCommand().equals(sendImage.getActionCommand())){
                //imageSend(imageName.getText());
                sendMessage("***");                                                         //identifier for file sending. can be changed
                imageSend(imageName.getText());
            }
            if (x.getActionCommand().equals(btnLogout.getActionCommand()))					//logout
            {
                exit();
            }
        }
        catch(IOException e)
        {
            System.out.println("Button failure IO "+e);
        }
    }



    //public final static String FILE_TO_SEND = "C:/Users/ic/Desktop/libgdx programs/ChatApp/src/dog.jpg";  // you may change this
    private void imageSend(String imageName) throws FileNotFoundException {
        // send file
        lblMessage = new JLabel("cool!");
        fis = null;
        bis = null;
        os = null;
        File myFile = new File ("dog.jpg");

        try {
            byte [] mybytearray  = new byte [(int)myFile.length()];
            fis = new FileInputStream(myFile);
            bis = new BufferedInputStream(fis);
            bis.read(mybytearray,0,mybytearray.length);
            os = socket.getOutputStream();
            System.out.println("Sending " + imageName + "(" + mybytearray.length + " bytes)");
            os.write(mybytearray,0,mybytearray.length);
            os.flush();
            System.out.println("Done.");

        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (bis != null) try {
                bis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (os != null) try {
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }



    }
    // public  String FILE_TO_RECEIVED = "C:/Users/ic/Desktop/libgdx programs/ChatApp/src/dog.jpg";
    public final static int FILE_SIZE = 6022386;
    public void imageReceive(String path,String filename) throws IOException {
        // receive file

        current = 0;
        fos = null;
        bos = null;
        byte [] mybytearray  = new byte [FILE_SIZE];
        try {
            InputStream is = socket.getInputStream();
            fos = new FileOutputStream(filename);
            bos = new BufferedOutputStream(fos);
            bytesRead = is.read(mybytearray,0,mybytearray.length);
            current = bytesRead;

            do {
                bytesRead = is.read(mybytearray, current, (mybytearray.length-current));
                if(bytesRead >= 0)
                    current += bytesRead;
            } while(current < FILE_SIZE);

            bos.write(mybytearray, 0 , current);
            bos.flush();
            System.out.println("File " + filename + " downloaded (" + current + " bytes read)");
            File f = new File(path);
            Files.write(f.toPath(),mybytearray);
        }
        finally {
            if (fos != null) fos.close();
            if (bos != null) bos.close();
            //if (socket != null) socket.close();
        }
    }
    //small method to trigger send if enter key is pressed
    public void keyPressed(KeyEvent x)
    {
        if(x.getKeyCode()==KeyEvent.VK_ENTER)
        {
            try {sendMessage(textMessage.getText());}
            catch (IOException e) {e.printStackTrace();}
        }
    }

    public int imgNotification(){
        int choice = JOptionPane.showOptionDialog(null, //Component parentComponent
                "Do you want to recieve image?", //Object message,
                "Choose an option", //String title
                JOptionPane.OK_CANCEL_OPTION, //int optionType
                JOptionPane.QUESTION_MESSAGE, //int messageType
                null, //Icon icon,
                new String[]{"receive", "decline"}, //Object[] options,
                "receive");//Object initialValue
        if(choice == 0 ){
            //yes was chosen
            return 0;
        }else{
            //Imperial was chosen
            return 1;
        }
    }

    //tiny main basically just uses the methods we have outlined
    public static void main(String args[]) throws IOException
    {
        Client c = new Client();							//constructs this client, making sure its new so each cleint is its own entity
        c.connect(); 										//connection
        c.listen(); 										//wait for incoming message
    }


    public void mouseClicked(MouseEvent arg0)
    {
        if(arg0.getComponent().equals(textMessage))
        {
            textMessage.setText("");
        }
        if(arg0.getComponent().equals(imageName))
        {
            imageName.setText("");
        }
    }


    @Override
    public void keyReleased(KeyEvent arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void keyTyped(KeyEvent arg0) {
        // TODO Auto-generated method stub

    }

    public void mouseEntered(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    public void mouseExited(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    public void mousePressed(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }

    public void mouseReleased(MouseEvent arg0) {
        // TODO Auto-generated method stub

    }
}

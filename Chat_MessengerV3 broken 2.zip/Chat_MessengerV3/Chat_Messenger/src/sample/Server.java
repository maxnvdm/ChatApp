package sample;

import javax.swing.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;

//class extends thread because each client will spawn a new thread who's job will be to wait for a message
//the server will then manage these threads
class Server extends Thread
{
    private static HashMap<String, BufferedWriter> connectedClients; 	//stores a list of clients, or atleast their BW's
    private static HashMap<String, byte[]> clientsData;
    private static ServerSocket server; 						//for creation of server
    private String clientName; 									//holds current message string
    private Socket connectingSocket; 							//initialized on creation as inputed socket
    private InputStream inputStream; 							//is the incoming stream
    private InputStreamReader inputRead; 						//to read incoming messages from stream
    private BufferedReader brIn;								//its da buffered reader obvs

    private int bytesRead;
    private int current ;
    private FileOutputStream fos ;
    private BufferedOutputStream bos ;

    private FileInputStream fis = null;
    private BufferedInputStream bis = null;
    private OutputStream os = null;

    //the constructor will accept a socket as parameter, then assign all I/O components
    //necessary to correctly read from the socket
    Server(Socket sock)
    {
        this.connectingSocket=sock;							 //assign socket
        try
        {
            inputStream = connectingSocket.getInputStream(); //get the input stream from the socket
            inputRead = new InputStreamReader(inputStream);  //read from that input stream
            brIn = new BufferedReader(inputRead);			 //then use that in a bufferedReader
        }
        catch (IOException e)
        {
            sop("failed at constructor"+e);  //if one of the I/O assignments fail
        }
    }

    //Run() is what happens when a new client connects to the server. the method is then given a thread which
    //checks for new messages and if there are any, it first gets read, then sets off the sendToClients() method
    public void run()
    {
        try
        {
            String message;										 //will store the read message

            OutputStream out = this.connectingSocket.getOutputStream();//creates an output stream through the socket
            Writer outWriter = new OutputStreamWriter(out);		 //lets us write to the output stream
            BufferedWriter brOut = new BufferedWriter(outWriter);//then uses that in a buffered Writer
            byte[] data = new byte[78979];
            message = brIn.readLine();							//reads the message that this client just sent in
            connectedClients.put(message, brOut);						//stores the bufferedWriter of this client
            clientsData.put(message,data);
            clientName=message;									//first message is connected clients name

            if (!connectingSocket.isClosed()) sendToClients(brOut, "CLIENTNAME:"+clientName);
            while(message!=null && !message.equals("EXIT") && !connectingSocket.isClosed())  	//checks if there is a message, and that its not to exit the chat
            {
                if (message.contains("@")) {
                    whisper(message);
                    sop(message);
                }
                else if (message.contains("*")){
                    message = message.substring(message.indexOf("*")+1,message.length());
                    message = brIn.readLine();                        //read that message again
                    sendToClients(brOut, message);                    //sends message out through output writer
                    sop(message);                                    //print the message
                }else {
                    System.out.println("okay we sending files now");
                }
            }
            if (message.equals("EXIT")) {sendToClients(brOut, "REMOVECLIENT:"+clientName);}
        }
        catch (Exception e)
        {
            sop("Run() failure"+e);
        }
    }


    public void whisper(String message) throws IOException{
        String username = message.substring(message.indexOf("@") + 1, message.indexOf(" "));
        BufferedWriter whisper = (BufferedWriter)connectedClients.get(username);
        whisper.write(clientName+ " :> "+message+"\r\n");
        whisper.flush();
    }

    //will read and send out the message to all other connected clients by going through
    //each client and sending the message
    public void sendFileToClients (byte[] data,String s) throws IOException
    {
        //sendToClients();
    }
    public void sendToClients(BufferedWriter bw,String s) throws IOException
    {
        BufferedWriter tempBw; 										//temporary variable
        for(BufferedWriter clientsbw : connectedClients.values())			//for each buffWriter in list of clients
        {
            tempBw = (BufferedWriter)clientsbw; 					//convert an ArrayList buffWriter item to just a buffWriter
            if(!(clientsbw == bw))									//wont send to client who typed message
            {
                //System.out.println("sending message to client");
                if (s.contains("CLIENTNAME:")||s.contains("REMOVECLIENT:")) clientsbw.write(s + "\r\n"); // send/remove client name only (for list of active users)
                else clientsbw.write(clientName + " :> " + s + "\r\n");        //everyone else gets message
                ///admin
                //System.out.println("wrote normal message");
                clientsbw.flush();
            }
        }
    }

    //Okay now finally the main method, this will configure the server and port number. This method will block on
    //the accept() method which waits for another client to connect, and when a client does, will spawn a new thread
    //for that client
    public static void main(String[] args)
    {
        try
        {

            JLabel portInputLbl = new JLabel("Server port: ");					//\
            JTextField portInput = new JTextField("2018");						// \
            Object[] inputs ={portInputLbl,portInput};
            JOptionPane.showMessageDialog(null,inputs);							//   all silly GUI stuff (simplify this)

            server = new ServerSocket(Integer.parseInt(portInput.getText()));	//create server from given port number
            connectedClients = new HashMap<String, BufferedWriter>();				//instantiate list of clients
            JOptionPane.showMessageDialog(null,"Server live with port: "+portInput.getText());

            while(true)
            {
                System.out.println("Server running, awaiting clients...");				//lets us know server is live
                if(connectedClients.size()==20){
                    System.out.println("Maximum of 20 clients has been reached");
                    continue;
                }
                Socket connectingSocket = server.accept();						//method blocks here waiting for a new client
                System.out.println("New login. Connected to: " + connectingSocket.getInetAddress().getHostName());	//tells us someone connected
                Thread clientThread = new Server(connectingSocket);					//spawn off new thread for client
                clientThread.start();                                               //sets off Run() method in new thread
                //cliThred.run();
            }
        }
        catch (Exception e)
        {
            System.out.println("nope main failure"+ e);
        }
    }

    public void sop(String s)
    {
        System.out.println(s);
    }
}
